import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class StringTest {

    private String test;

    @Before
    public void setUp() {
        test = "Hello World";
    }

    @Test
    public void testStringLength() {
        assertEquals(11, test.length());
    }

    @Test
    public void testCharAt() {
        assertEquals('H', test.charAt(0));
        assertEquals('o', test.charAt(4));
        assertEquals('d', test.charAt(10));
    }

    @Test
    public void testSubstring() {
        assertEquals("Hello", test.substring(0, 5));
        assertEquals("World", test.substring(6, 11));
        assertEquals("lo W", test.substring(3, 7));
    }

    @Test
    public void testIndexOf() {
        assertEquals(6, test.indexOf("World"));
        assertEquals(3, test.indexOf("lo"));
        assertEquals(-1, test.indexOf("Java"));
    }
}

